package lab.four.test;

import static java.security.AccessController.getContext;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class taula extends AppCompatActivity {

    private EditText editTextFilter;   // Agafar el que volem mirar
    private TextView text;           //  mostrar text
    private Button buttonSend, logoutButton;           // El botó per enviar la query


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new); // Asegúrate que el layout contiene el TableLayout
        buttonSend = findViewById(R.id.buttonSend); //Inicialitzar botó send
        TableLayout tableLayout = findViewById(R.id.tableLayout); // Obtén el TableLayout del diseño
        editTextFilter = findViewById(R.id.editTextText);
        text = findViewById(R.id.text_gallery);
        logoutButton = findViewById(R.id.logoutButton);

        text.setText("Welcome "+Connexio.getNom().split(" ")[0]+"!");

        //Verificar que buttonsend es null per identificar errors
        if(buttonSend==null)
            throw new NullPointerException("El botó no es troba en el Layout");

        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String filterText = editTextFilter.getText().toString().trim(); // Obtén el filtro del EditText
                System.out.println(filterText);

                String serverIP = RutaManager.getInstance().getRuta();
                Connexio c = new Connexio(serverIP);

                c.queryTable(filterText,
                        data -> {
                            // les dades en format taula
                            runOnUiThread(() -> displayDataInTable(data, tableLayout));
                        },
                        error -> {
                            // Maneja errores y muestra un mensaje
                            runOnUiThread(() -> {

                                if (error != null) {
                                    if(error.equals("Error: 600 - {\"error\":\"Sessió no iniciada o caducada\"}")) {
                                        Toast.makeText(taula.this, "Sessió caducada", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(taula.this, MainActivity.class);
                                        startActivity(intent);
                                        finish();
                                    }else{
                                        Toast.makeText(taula.this, "Error al realitzar la consulta, torna-ho a provar", Toast.LENGTH_SHORT).show();
                                    }
                                }

                            });
                        });
            }
        });

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(taula.this, MainActivity.class);
                startActivity(intent);
                finish(); }
        });
    }



    // Mètode per mostrar les dades en una taula
    private void displayDataInTable(Map<String, List<Object>> data, TableLayout tableLayout) {
        // Asegurar que la taula no té files prèvies
        tableLayout.removeAllViews();

        // Crear una llista de claus i obtenir el número màxim de valors
        List<String> keys = new ArrayList<>(data.keySet());
        int maxRows = 0;
        for (List<Object> values : data.values()) {
            maxRows = Math.max(maxRows, values.size());
        }

        // 1a fila: afegir els noms de les columnes (keys)
        // Primera fila: añadir los nombres de las columnas (keys)
        TableRow headerRow = new TableRow(this);
        for (String key : keys) {
            TextView textView = new TextView(this);
            textView.setText(key);
            textView.setPadding(16, 16, 16, 16);
            textView.setTextSize(16);
            textView.setBackgroundColor(0xFFEFEFEF); // Fondo clar
            textView.setTextColor(0xFF000000); // Text negre
            headerRow.addView(textView);
        }
        tableLayout.addView(headerRow);

        // Afegir les files amb els valors
        for (int i = 0; i < maxRows; i++) {
            TableRow tableRow = new TableRow(this);
            for (String key : keys) {
                TextView textView = new TextView(this);
                List<Object> columnData = data.get(key);
                String cellValue = (i < columnData.size()) ? columnData.get(i).toString() : ""; // Evita nulls
                textView.setText(cellValue);
                textView.setPadding(16, 16, 16, 16);
                textView.setTextSize(16);
                textView.setBackgroundColor(0xFFF5F5F5); // Fondo alternatiu
                textView.setTextColor(0xFF000000); // Text negre
                tableRow.addView(textView);
            }
            tableLayout.addView(tableRow);
        }
    }








}