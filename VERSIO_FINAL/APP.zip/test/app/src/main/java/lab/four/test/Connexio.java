package lab.four.test;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class Connexio {

    /* Quan es vulgui iniciar la sessió es demana la url, llavors es fa un objecte de la classe
     * connexio, que cada una guardarà la url que s'utilitza
     *
     *   - al tornar el nom en el authenticate, que es compari amb el que s'ha introduit al iniciar
     *    sessio
     *
     *   - En el Login que es guardin les 3 coses en strings
     *
     */

    private static String BASE_URL = ""; //Es demana quan s'inicia sessió

    private static String nom_text;

    // Constructor
    public Connexio(String url) {
        BASE_URL = url;
    }

    // Peticio HTTP --> El GET
    public static void fetchData(
            String path,   //path per a l url, es diu la taula
            Map<String, String> params, //filtres que es vulguin afegir
            Callback<Object> onSuccess, //dades que s'han rebut, es retornen amb un callback    Amb object pq no hi hagi error entre JSONOBject i JSONArray
            Callback<String> onError, //error
            Callback<String> onException) {

        ExecutorService executorService = Executors.newCachedThreadPool();

        executorService.execute(() -> {
            try {
                // Construcción de la URL
                StringBuilder urlBuilder = new StringBuilder(BASE_URL).append(path);
                if (params != null && !params.isEmpty()) {
                    urlBuilder.append("?");
                    for (Map.Entry<String, String> entry : params.entrySet()) {
                        urlBuilder.append(URLEncoder.encode(entry.getKey(), "UTF-8"))
                                .append("=")
                                .append(URLEncoder.encode(entry.getValue(), "UTF-8"))
                                .append("&");
                    }
                    urlBuilder.setLength(urlBuilder.length() - 1); // Elimina el último "&"
                }

                URL url = new URL(urlBuilder.toString());

                // Conexión con el servidor y método GET para obtener los datos
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                int responseCode = connection.getResponseCode();

                try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                        responseCode == 200 ? connection.getInputStream() : connection.getErrorStream()))) {

                    String response = reader.lines().collect(Collectors.joining("\n"));

                    if (responseCode == 200) {
                        // Detecta si es JSONObject o JSONArray
                        try {
                            Object jsonResponse = response.trim().startsWith("{")
                                    ? new JSONObject(response)
                                    : new JSONArray(response);
                            onSuccess.call(jsonResponse);
                        } catch (JSONException e) {
                            onError.call("Error en el formato de la respuesta del servidor.");
                        }
                    } else {
                        String errorMessage = "Error: " + responseCode + " - " + response;
                        onError.call(errorMessage);
                    }
                }
            } catch (Exception e) {
                if (onException != null) {
                    onException.call("Error al conectar con el servidor: " + e.getMessage());
                }
                e.printStackTrace();
            }
        });
    }


    // Posar en el format que volem
    // Retorna un mapa on les keys son les diferents columnes, i per a cada columna te una llista amb tots els valors
    public static Map<String, List<Object>> processData(JSONArray data, List<String> selectedColumns) {
        Map<String, List<Object>> result = selectedColumns.stream()
                .collect(Collectors.toMap(column -> column, column -> new ArrayList<>()));

        // Itera sobre el JSONArray
        for (int i = 0; i < data.length(); i++) {
            try {
                JSONObject row = data.getJSONObject(i); // Obtiene el objeto en la posición i
                for (String column : selectedColumns) {
                    if (row.has(column)) {
                        Object value;
                        if ("date".equals(column)) {
                            value = formatDate(row.getString(column)); // Pone la fecha en formato YY-MM-DD
                        } else {
                            value = row.get(column);
                        }
                        result.get(column).add(value);
                    }
                }
            } catch (JSONException e) {
                throw new RuntimeException("Error al procesar datos: " + e.getMessage(), e);
            }
        }
        return result;
    }

    // Autentificar l'usuari al iniciar la sessió
    public void authenticateUser(String uid, Callback<String> nom, Callback<String> error) {
        fetchData(
                "/authenticate",
                Map.of("uid", uid),
                data -> {
                    if (data instanceof JSONObject) {
                        JSONObject jsonObject = (JSONObject) data;
                        String name = jsonObject.optString("name", null);
                        nom_text = name;
                        if (name != null) {
                            nom.call(name);
                        } else {
                            error.call("Error d'autenticació. Torna-ho a intentar.");
                        }
                    } else {
                        error.call("Resposta inesperada del servidor.");
                    }
                },
                error::call,
                exception -> error.call("Error al connectar amb el servidor: " + exception)
        );
    }


    //Consultar la taula que es demana
    public void queryTable(String nomTaula,
                           Callback<Map<String, List<Object>>> taula,
                           Callback<String> error) {

        Map<String, String> params = new HashMap<>();
        String table = null;
        if (!nomTaula.contains("?")) {
            table = nomTaula;
        } else {
            String[] parts = nomTaula.split("\\?", 2);
            table = parts[0];
            params.putAll(parseFilters(parts[1]));
        }
        if (table == null || table.isEmpty()) {
            error.call("Error: taula desconeguda.");
            return;
        }
        params.put("table", table);

        String finalTable = table;
        fetchData(
                "/query",
                params,
                result -> {
                    if (result instanceof JSONArray) {
                        JSONArray jsonArray = (JSONArray) result;
                        Map<String, List<Object>> data;
                        switch (finalTable) {
                            case "timetables":
                                data = processData(jsonArray, List.of("day", "hour", "Subject", "Room"));
                                break;
                            case "tasks":
                                data = processData(jsonArray, List.of("date", "subject", "name"));
                                break;
                            case "marks":
                                data = processData(jsonArray, List.of("Subject", "Name", "Marks"));

                                break;
                            default:
                                error.call("Error: taula desconeguda.");
                                return;
                        }
                        if (!data.isEmpty()) {
                            taula.call(data);
                        } else {
                            error.call("No hi ha dades disponibles per a la taula " + finalTable);
                        }
                    } else {
                        error.call("Resposta inesperada del servidor.");
                    }
                },
                error::call,
                exception -> error.call(exception)
        );
    }


    //Formatejar les dates
    private static String formatDate(String date) {
        return date.length() >= 10 ? date.substring(0, 10) : date;
    }

    // Parsejar filtres
    private Map<String, String> parseFilters(String filterString) {
        Map<String, String> filters = new HashMap<>();
        if (filterString != null && !filterString.isEmpty()) {
            Arrays.stream(filterString.split("&"))
                    .map(pair -> pair.split("=", 2))
                    .filter(keyValue -> keyValue.length == 2)
                    .forEach(keyValue -> filters.put(keyValue[0], keyValue[1]));
        }
        return filters;
    }

    // Interfaz para callbacks genéricos
    public interface Callback<T> {
        void call(T result);
    }

    // Interfaz para entradas de usuario (Prompt)
    public interface PromptCallback<T> {
        T prompt(String message);
    }
    public static String getNom() {
        return nom_text;
    }
}
