package lab.four.test;

//CLASSE PER GUARDAR EL VALOR DE LA BASE LA LA URL QUE ANEM FENT SERVIR

public class RutaManager {
    private static RutaManager instance;
    private String ruta;

    private RutaManager() {}

    public static synchronized RutaManager getInstance() {
        if (instance == null) {
            instance = new RutaManager();
        }
        return instance;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }
}
