package lab.four.test;

import static androidx.core.content.ContentProviderCompat.requireContext;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class MainActivity extends AppCompatActivity {

    // Variables per als camps de text i botó
    private EditText editTextRFID, editTextUsername, editTextServerIP;
    private Button buttonLogin;
    private Connexio c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Configura el padding automàtic per a les insets del sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Associa les variables amb els elements del layout
        editTextRFID = findViewById(R.id.editTextTextPassword);
        editTextUsername = findViewById(R.id.editTextTextPassword2);
        editTextServerIP = findViewById(R.id.editTextTextPassword3);
        buttonLogin = findViewById(R.id.button2);

        // Configura el listener del botó
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Guarda els valors dels camps de text en variables
                String password = editTextRFID.getText().toString();
                String username = editTextUsername.getText().toString();
                String ruta = editTextServerIP.getText().toString();


                // Comprovacio de dades


                c = new Connexio(ruta);
                validateInputs(username, password, ruta,
                        isValid -> {
                            //Assegurar que Toast es al fil principal
                            runOnUiThread(() -> {
                                if (isValid) {
                                    Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                                    RutaManager.getInstance().setRuta(ruta);

                                    // Iniciar l'activitat de la taula
                                    Intent intent = new Intent(MainActivity.this, taula.class);
                                    startActivity(intent);

                                    // Finalitzar l'actividad actual
                                    finish();

                                } else {
                                    Toast.makeText(MainActivity.this, "Incorrect username or password", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                );
            }
        });
    }
    public Connexio getConnexio(){
        return c;
    }

    private void validateInputs(String username, String uid, String url, Callback<Boolean> resultCallback) {
        // Validació
        Connexio connexio = new Connexio(url);

        connexio.authenticateUser(uid,
                nom -> {
                    boolean isValid = nom.trim().equals(username.trim());
                    System.out.println(isValid);
                    resultCallback.call(isValid);
                },
                error -> resultCallback.call(false)
        );

    }

    @FunctionalInterface
    public interface Callback<T> {
        void call(T result);
    }



}


